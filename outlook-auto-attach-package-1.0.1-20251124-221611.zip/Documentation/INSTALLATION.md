# Outlook Auto Attach - Installation Guide

## Overview
This package contains:
1. **Chrome Extension** - Detects downloads and sends them to the server
2. **Server Application** - Opens Outlook and attaches files

## Installation Steps

### Step 1: Install Chrome Extension

1. Open Chrome and go to `chrome://extensions/`
2. Enable **Developer mode** (toggle in top right)
3. Click **Load unpacked**
4. Select the `Chrome Extension` folder from this package
5. The extension should now appear in your extensions list

### Step 2: Install Server Application

#### For Mac users:
1. Open the `Server/Mac` folder
2. Double-click `Outlook Auto Attach Server.app` to start it
   - **First time**: Mac may warn about unsigned app - right-click and select "Open", then click "Open" again
3. The server starts automatically - you can minimize or close the window
4. The server will keep running in the background

**Optional - Start on Login:**
1. Drag `Outlook Auto Attach Server.app` to your **Applications** folder (recommended)
2. Go to **System Settings → Users & Groups → Login Items** (or **System Preferences → Users & Groups → Login Items**)
3. Click **+** button
4. Select "Outlook Auto Attach Server" from Applications
5. ✅ Server will start automatically when you log in

#### For Windows users:
1. Open the `Server/Windows` folder
2. Double-click `Outlook Auto Attach Server.exe` to start it
3. The server window will open - click **Start Server**
4. You can minimize the window - the server will keep running

**Optional - Start on Login:**
1. Right-click `Outlook Auto Attach Server.exe`
2. Select "Create shortcut"
3. Press `Win + R`, type `shell:startup`, press Enter
4. Copy the shortcut to the Startup folder

## Usage

1. **Make sure the server is running**
   - Double-click `Outlook Auto Attach Server.app` (Mac) or `Outlook Auto Attach Server.exe` (Windows)
   - The server starts automatically - no need to click any buttons
   - You can verify it's running by checking http://localhost:8765/status in your browser (should show "Outlook Auto Attach Server is running")

2. **Download a file** that contains "Orderbekräftelse", "Inköp", or "1000322" in the filename

3. **The extension will detect it** and show a notification with a badge on the extension icon

4. **Click the extension icon** in Chrome to open the confirmation popup

5. **Click "Open Outlook"** - Outlook will open with the file attached!

**Note**: The server runs automatically when you start the app - you don't need to manually start it!

## Troubleshooting

### Server won't start
- Check if port 8765 is already in use
- Try stopping and restarting the server
- Make sure Microsoft Outlook is installed

### Extension not working
- Make sure the server is running (Status: Running)
- Check that you're downloading files with "Orderbekräftelse", "Inköp", or "1000322" in the name
- Check Chrome's extension console for errors (chrome://extensions/ → Details → Inspect views → Service worker)

### Outlook doesn't open
- Make sure Microsoft Outlook is installed
- Check the server log window for error messages
- Try restarting both the server and Chrome

## Support
For issues or questions, contact your IT department.

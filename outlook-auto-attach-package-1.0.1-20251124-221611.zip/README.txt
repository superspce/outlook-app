Outlook Auto Attach - Distribution Package
Version: 1.0.1
Created: 20251124-221611

QUICK START:
1. Install Chrome Extension (see Documentation/INSTALLATION.md)
2. Run the Server Application for your OS (Mac or Windows)
3. Click "Start Server" in the server window
4. Download files with "Orderbekräftelse", "Inköp", or "1000322" in the name

For detailed instructions, see: Documentation/INSTALLATION.md
